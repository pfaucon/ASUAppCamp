//
//  ViewController.swift
//  MicrophoneLab
//
//  Created by Xiaoxiao on 6/25/16.
//  Copyright © 2016 WangXiaoxiao. All rights reserved.
//

import UIKit

class CameraViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // Image view property from the storyboard.
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
    }
    
    // Take photo action from the storyboard.
    @IBAction func takePhoto(sender: UIButton) {
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera) {
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.allowsEditing = true
            picker.sourceType = UIImagePickerControllerSourceType.Camera
            
            presentViewController(picker, animated: true, completion: nil)
        }
        else {
            print("Oh noes, the camera doesn't work on the simulator!")
        }
    }
    
    // Select photo action from the storyboard.
    @IBAction func selectPhoto(sender: UIButton) {
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.SavedPhotosAlbum) {
            let picker = UIImagePickerController()
            picker.delegate = self
            picker.allowsEditing = true
            picker.sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum
            
            presentViewController(picker, animated:true, completion: nil)
        }
    }
    
    // Call this function when an image picker operation is done.
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        let chosenImage = info[UIImagePickerControllerEditedImage] as? UIImage
        self.imageView.image = chosenImage
        picker.dismissViewControllerAnimated(true, completion: nil)
        
        // State model update.
        let model = StateModel.sharedInstance
        model.image = chosenImage
        print(model.image)
    }
    
    // Call this function when an image picker operation is cancelled.
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        picker.dismissViewControllerAnimated(true, completion: nil)
    }

}

