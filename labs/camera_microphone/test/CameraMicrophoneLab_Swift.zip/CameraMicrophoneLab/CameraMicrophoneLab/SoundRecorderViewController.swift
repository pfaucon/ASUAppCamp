//
//  SoundRecorderViewController.swift
//  CameraMicrophoneLab
//
//  Created by Xiaoxiao on 6/25/16.
//  Copyright © 2016 WangXiaoxiao. All rights reserved.
//

import UIKit
import AVFoundation

class SoundRecorderViewController: UIViewController, AVAudioRecorderDelegate, AVAudioPlayerDelegate {

    @IBOutlet weak var recordPauseButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    
    var recorder: AVAudioRecorder!
    var player: AVAudioPlayer!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
        // Disable Stop/Play buttons when application launches.
        self.stopButton.enabled = false
        self.playButton.enabled = false

        // Set up audio session.
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(AVAudioSessionCategoryPlayAndRecord)
        }
        catch {
            print("Failed to initialize recording session.")
        }
        
        // Define the recorder setting.
        let recordSetting = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 44100.0,
            AVNumberOfChannelsKey: 2 as NSNumber,
        ]
        
        // Set the audio file.
        let outputFileURL = getAudioURL()
        
        // Initialize and prepare the recorder.
        do {
            recorder = try AVAudioRecorder(URL: outputFileURL, settings: recordSetting)
            recorder.delegate = self
            recorder.meteringEnabled = true
            recorder.prepareToRecord()
        }
        catch {
            print("Failed to initialize the recorder.")
        }
        
    }

    // Where are we going to save the recording?
    func getAudioURL() -> NSURL {
        
        let pathComponents = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true) as [NSString]
        let audioFileName = pathComponents[0].stringByAppendingPathComponent("MyAudioMemo.m4a")
        return NSURL(fileURLWithPath: audioFileName)
    }

    @IBAction func recordPauseTapped(sender: UIButton) {
    
        // Stop the audio player before recording.
        
        if self.player != nil{
            if self.player.playing {
                self.player.stop()
            }
        }
        
        if !self.recorder.recording {
            
            let session = AVAudioSession.sharedInstance()
            do {
                try session.setActive(true)
            }
            catch {
                print("Fail to start recording session.")
            }
            
            // Start recording.
            self.recorder.record()
            self.recordPauseButton.setTitle("Pause", forState: .Normal)
        }
        else {
            
            // Pause recording.
            self.recorder.pause()
            self.recordPauseButton.setTitle("Record", forState: .Normal)
        }
        
        self.playButton.enabled = true
        self.stopButton.enabled = true
        
    }
    
    @IBAction func stopTapped(sender: UIButton) {
        
        self.recorder.stop()
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setActive(false)
        }
        catch {
            print("Failed to complete the recording.")
        }
    }
    
    func audioRecorderDidFinishRecording(recorder: AVAudioRecorder, successfully flag: Bool) {
     
        self.recordPauseButton.setTitle("Record", forState: .Normal)
        self.playButton.enabled = true
        self.stopButton.enabled = false
        
        // State model update.
        let model = StateModel.sharedInstance
        model.setRecURL(self.getAudioURL())

    }
    
    @IBAction func playTapped(sender: UIButton) {
        
        if !self.recorder.recording {
            do {
                self.player = try AVAudioPlayer(contentsOfURL: self.getAudioURL())
                self.player.delegate = self
                self.player.play()
            }
            catch {
                print("Failed to initialize the player.")
            }
        }
    }
    
    func audioPlayerDidFinishPlaying(player: AVAudioPlayer, successfully flag: Bool) {
        let alert = UIAlertController(title: "Done", message: "Recording completed successfully!", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
